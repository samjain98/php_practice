<?php include '../view/header.php'; 
    /* 
 * Sameer Jain
 * sameejain@my.smccd.edu
 * CIS 380
 * OL
 * Assignment #3
 * Sameer Jain
 * 9/15/15
 */
?>
<main>
    <h1>Error</h1>
    <p class="first_paragraph"><?php echo $error; ?></p>
</main>
<?php include '../view/footer.php'; ?>