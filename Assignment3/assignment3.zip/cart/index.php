<?php include '../view/header.php'; 
    /* 
 * Sameer Jain
 * sameejain@my.smccd.edu
 * CIS 380
 * OL
 * Assignment #3
 * Sameer Jain
 * 9/15/15
 */
?>

<main>
    <h1>Shopping Cart - under construction</h1>
</main>

<?php include '../view/footer.php'; ?>
