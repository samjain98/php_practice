<?php
    /* 
 * Sameer Jain
 * sameejain@my.smccd.edu
 * CIS 380
 * OL
 * Assignment #3
 * Sameer Jain
 * 9/15/15
 */
?>
<footer>
    <p class="copyright">
        &copy; <?php echo date("Y"); ?> My Guitar Shop, Inc.
    </p>
</footer>
</body>
</html>