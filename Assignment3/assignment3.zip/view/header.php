<?php
    /* 
 * Sameer Jain
 * sameejain@my.smccd.edu
 * CIS 380
 * OL
 * Assignment #3
 * Sameer Jain
 * 9/15/15
 */
?>
<!DOCTYPE html>
<html>
<!-- the head section -->
<head>
    <title>My Guitar Shop</title>
    <link rel="stylesheet" type="text/css"
          href="/book_apps/ch05_guitar_shop/main.css">
</head>

<!-- the body section -->
<body>
<header><h1>My Guitar Shop</h1></header>
