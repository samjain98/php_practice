<?php include 'view/header.php'; 
    /* 
 * Sameer Jain
 * sameejain@my.smccd.edu
 * CIS 380
 * OL
 * Assignment #3
 * Sameer Jain
 * 9/15/15
 */
?>
<main>
    <h1>Menu</h1>
    <ul>
        <li>
            <a href="product_manager">Product Manager</a>
        </li>
        <li>
            <a href="product_catalog">Product Catalog</a>
        </li>
    </ul>
</main>
<?php include 'view/footer.php'; ?>